from brain_games.games import logic_games


def main():
    logic_games.any_game("brain_calc")



if __name__ == '__main__':
    main()