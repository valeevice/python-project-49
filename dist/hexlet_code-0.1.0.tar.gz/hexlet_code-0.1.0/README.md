### Hexlet tests and linter status:
[![Actions Status](https://github.com/valeevice/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/valeevice/python-project-49/actions)

### https://codeclimate.com/
<a href="https://codeclimate.com/github/valeevice/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/ba609632360327b2c902/maintainability" /></a>

### https://asciinema.org/ --- brain-even game
https://asciinema.org/a/532566

### https://asciinema.org/ --- brain-calc game
https://asciinema.org/a/532821

### https://asciinema.org/ --- brain-gcd game
https://asciinema.org/a/532840

### https://asciinema.org/ --- brain-progression game
https://asciinema.org/a/532869