### Hexlet tests and linter status:
[![Actions Status](https://github.com/valeevice/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/valeevice/python-project-49/actions)

<a href="https://codeclimate.com/github/valeevice/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/ba609632360327b2c902/maintainability" /></a>